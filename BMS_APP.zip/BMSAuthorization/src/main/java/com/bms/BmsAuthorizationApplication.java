package com.bms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BmsAuthorizationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BmsAuthorizationApplication.class, args);
	}

}
