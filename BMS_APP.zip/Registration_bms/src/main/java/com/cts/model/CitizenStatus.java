package com.cts.model;

public enum CitizenStatus {

	MINOR("Minor"), NORMAL("Normal"), SENIOR("SENIOR");

	CitizenStatus(String string) {
	}

}
